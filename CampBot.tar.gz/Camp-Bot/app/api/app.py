from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.staff import router as staff_router

app = FastAPI(title="Camp Bot API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(staff_router)


@app.get("/health")
async def health():
    return {"status": "ok"}
